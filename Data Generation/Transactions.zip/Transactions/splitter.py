# Open the input file
with open('files.txt', 'r') as infile:
    # Create three output files
    out1 = open('output1.txt', 'w')
    out2 = open('output2.txt', 'w')
    out3 = open('output3.txt', 'w')
    # Loop through each line in the input file
    for i, line in enumerate(infile):
        # Determine which output file to write to based on the index modulo 3
        if i % 3 == 0:
            out1.write(line)
        elif i % 3 == 1:
            out2.write(line)
        else:
            out3.write(line)
    # Close all files
    out1.close()
    out2.close()
    out3.close()
