
mortgage_companies = [
    'Quicken Loans',
    'Wells Fargo Home Mortgage',
    'Chase Home Lending',
    'Bank of America',
    'Guaranteed Rate',
    'LoanDepot',
    'Veterans United Home Loans',
    'United Wholesale Mortgage',
    'Caliber Home Loans',
    'Flagstar Bank',
    'Fairway Independent Mortgage',
    'Rocket Mortgage',
    'U.S. Bank',
    'Guild Mortgage',
    'Freedom Mortgage',
    'New American Funding',
    'CitiMortgage',
    'PennyMac Loan Services',
    'CrossCountry Mortgage',
    'Movement Mortgage',
    'Stearns Lending',
    'BB&T',
    'PrimeLending',
    'Plaza Home Mortgage',
    'Homebridge Financial Services',
    'PHH Mortgage',
    'Mr. Cooper',
    'Fifth Third Bank',
    'Citizens Bank',
    'Axos Bank',
    'loanDepot Wholesale',
    'Gateway First Bank',
    'NBKC Bank',
    'Envoy Mortgage',
    'Pacific Union Financial',
    'The Money Source',
    'Academy Mortgage',
    'Paramount Residential Mortgage Group',
    'Waterstone Mortgage',
    'Cornerstone Home Lending',
    'Quontic Bank',
    'FirstBank',
    'AnnieMac Home Mortgage',
    'Summit Mortgage Corporation',
    'Fairway Wholesale Lending',
    'Finance of America Mortgage',
    'American Pacific Mortgage',
    'Sun West Mortgage',
    'Sierra Pacific Mortgage',
    'VIP Mortgage',
    'Total Mortgage',
    'Gold Star Mortgage Financial Group',
    'Amerisave Mortgage Corporation',
    'Home Point Financial',
    'Fidelity Funding Mortgage Corporation',
    'Nations Lending Corporation',
    'Primary Residential Mortgage',
    'HomeStreet Bank',
    'LeaderOne Financial Corporation',
    'Guaranty Home Mortgage',
    'Axia Home Loans',
    'Norcom Mortgage',
    'Guild Mortgage Wholesale',
    'Homeowners Financial Group',
    'OVM Financial',
    'BancorpSouth Mortgage',
    'Cornerstone First Financial',
    'Gateway Mortgage Group',
    'South Pacific Financial Corporation',
    'Diamond Residential Mortgage Corporation',
    '1st Security Bank Home Lending',
    'Intercontinental Capital Group',
    'Mortgage Network',
    'Platinum Home Mortgage',
    'American Financial Network',
    'Magnolia Bank',
    'Premier Nationwide Lending',
    'AmeriHome Mortgage Company',
    'Residential Home Funding Corp.',
    'Silverton Mortgage',
    'Mortgage Solutions Financial',
    'Mason-McDuffie Mortgage Corporation',
    'Carrington Mortgage Services',
    'The Federal Savings Bank',
    'First Option Mortgage',
    'Nationwide Mortgage Bankers',
    'Great Lakes Mortgage Financial',
    'Peoples Home Equity',
    'Nationwide Home Loans',
    'Garden State Home Loans',
    'Griffin Funding',
    'Motto Mortgage',
    'Eagle Home Mortgage',
    'Fortren Funding',
    'Sente Mortgage',
    'EPM',
    'Franklin American Mortgage Company',
    'AmeriSave Mortgage Corporation Wholesale',
    'Franklin Loan Center',
    'NewRez Wholesale',
]

uk_councils = [
    'Aberdeen City Council',
    'Aberdeenshire Council',
    'Angus Council',
    'Argyll and Bute Council',
    'Bath and North East Somerset Council',
    'Bedford Borough Council',
    'Blackburn with Darwen Borough Council',
    'Blackpool Council',
    'Blaenau Gwent County Borough Council',
    'Bolton Metropolitan Borough Council',
    'Bournemouth, Christchurch and Poole Council',
    'Bracknell Forest Council',
    'Bridgend County Borough Council',
    'Brighton and Hove City Council',
    'Bristol City Council',
    'Buckinghamshire Council',
    'Caerphilly County Borough Council',
    'Cambridgeshire County Council',
    'Camden London Borough Council',
    'Cardiff Council',
    'Carmarthenshire County Council',
    'Central Bedfordshire Council',
    'Ceredigion County Council',
    'Cheshire East Council',
    'Cheshire West and Chester Council',
    'City and County of Swansea Council',
    'City of London Corporation',
    'City of York Council',
    'Conwy County Borough Council',
    'Cornwall Council',
    'Coventry City Council',
    'Croydon London Borough Council',
    'Cumbria County Council',
    'Darlington Borough Council',
    'Denbighshire County Council',
    'Derby City Council',
    'Derbyshire County Council',
    'Devon County Council',
    'Dorset Council',
    'Dudley Metropolitan Borough Council',
    'Durham County Council',
    'Ealing London Borough Council',
    'East Sussex County Council',
    'Essex County Council',
    'Flintshire County Council',
    'Gateshead Council',
    'Gloucestershire County Council',
    'Greenwich London Borough Council',
    'Gwynedd Council',
    'Hackney London Borough Council',
    'Halton Borough Council',
    'Hammersmith and Fulham London Borough Council',
    'Hampshire County Council',
    'Haringey London Borough Council',
    'Harrow London Borough Council',
    'Hartlepool Borough Council',
    'Havering London Borough Council',
    'Herefordshire Council',
    'Hertfordshire County Council',
    'Highland Council',
    'Hillingdon London Borough Council',
    'Hounslow London Borough Council',
    'Inverclyde Council',
    'Isle of Anglesey County Council',
    'Isle of Wight Council',
    'Isles of Scilly Council',
    'Islington London Borough Council',
    'Kensington and Chelsea London Borough Council',
    'Kent County Council',
    'Kingston upon Hull City Council',
    'Kingston upon Thames London Borough Council',
    'Kirklees Council',
    'Knowsley Metropolitan Borough Council',
    'Lambeth London Borough Council',
    'Lancashire County Council',
    'Leeds City Council',
    'Leicester City Council',
    'Leicestershire County Council',
    'Lewisham London Borough Council',
    'Lincolnshire County Council',
    'Liverpool City Council',
    'Luton Borough Council',
    'Manchester City Council',
    'Medway Council',
    'Merthyr Tydfil County Borough Council',
    'Merton London Borough Council',
    'Mid and East Antrim Borough Council',
    'Mid Ulster District Council',
    'Middlesbrough Council',
    'Midlothian Council',
    'Monmouthshire County Council',
    'Moray Council',
    'Neath Port Talbot County Borough Council',
    'Newcastle City Council',
    'Newport City Council',
    'Newry, Mourne and Down District Council',
    'Norfolk County Council',
    'North Ayrshire Council',
    'North East Lincolnshire Council',
    'North Lanarkshire Council']

uk_water_companies = [    'Affinity Water',
                          'Anglian Water',
                          'Bristol Water',
                          'Cambridge Water',
                          'Dŵr Cymru Welsh Water',
                          'Northumbrian Water',
                          'Portsmouth Water',
                          'Severn Trent Water',
                          'South East Water',
                          'Southern Water',
                          'Thames Water']

uk_energy_providers = [
    'British Gas',
    'EDF Energy',
    'E.ON',
    'npower',
    'ScottishPower',
    'SSE',
    'Bulb Energy',
    'Octopus Energy',
    'Shell Energy',
    'OVO Energy',
    'Green Network Energy',
    'Utilita Energy',
    'Ecotricity',
    'Flow Energy',
    'Good Energy',
    'Outfox The Market',
    'Peoples Energy Company',
    'Pure Planet',
    'So Energy'
]

uk_charities = [
    'ActionAid UK',
    'Age UK',
    'Alzheimer’s Society',
    'Amnesty International UK',
    'Barnardo’s',
    'Beat',
    'Blue Cross',
    'Breast Cancer Now',
    'British Heart Foundation',
    'British Red Cross',
    'Cancer Research UK',
    'CARE International UK',
    'Carers UK',
    'Centrepoint',
    'Children with Cancer UK',
    'Child Poverty Action Group',
    'Christian Aid',
    'Crisis',
    'Dogs Trust',
    'Epilepsy Action',
    'Guide Dogs',
    'Help Musicians UK',
    'Hospice UK',
    'Hospitals of Hope',
    'Humanists UK',
    'International Rescue Committee UK',
    'JDRF UK',
    'Kidscape',
    'Leonard Cheshire',
    'Macmillan Cancer Support',
    'Mencap',
    'Mind',
    'Missing People',
    'Motor Neurone Disease Association',
    'MS Society',
    'Muscular Dystrophy UK',
    'National Autistic Society',
    'National Deaf Children’s Society',
    'National Trust',
    'NSPCC',
    'Oxfam GB',
    'Parkinson’s UK',
    'PDSA',
    'Plan International UK',
    'Practical Action',
    'Prostate Cancer UK',
    'Rainbow Trust Children’s Charity',
    'Refuge',
    'RNIB',
    'RNLI',
    'RSPB',
    'RSPCA',
    'Samaritans',
    'Save the Children UK',
    'Scope',
    'Sense',
    'Shelter',
    'Sightsavers',
    'St John Ambulance',
    'Stroke Association',
    'Sue Ryder',
    'Tearfund',
    'Teenage Cancer Trust',
    'The Children’s Society',
    'The Eve Appeal',
    'The Royal British Legion',
    'The Royal Marsden Cancer Charity',
    'The Salvation Army',
    'The Trussell Trust',
    'The Wildlife Trusts',
    'Tommy’s',
    'Turn2us',
    'UNICEF UK',
    'VSO',
    'WaterAid',
    'WellChild',
    'WWF-UK',
    'YMCA England & Wales',
    'YoungMinds',
    'Youth Music',
    'ZSL (Zoological Society of London)',
    'Marie Curie',
    'Headway',
    'Action for Children',
    'Action on Hearing Loss',
    'Age International',
    'All Dogs Matter',
    'Anthony Nolan',
    'Bowel Cancer UK',
    'Brain Tumour Research',
    'British Skin Foundation',
    'Campaign Against Living Miserably (CALM)',
    'Cancer Support UK',
    'Cats Protection',
    'Childline',
    'Cystic Fibrosis Trust',
    'Debra',
    'Depaul UK',
    'Disasters Emergency Committee (DEC)',
    'Family Fund'
    ]

restaurants = [
    'McDonald\'s',
    'Burger King',
    'KFC',
    'Subway',
    'Pizza Hut',
    'Domino\'s Pizza',
    'Taco Bell',
    'Wendy\'s',
    'Papa John\'s',
    'Chipotle Mexican Grill',
    'Nando\'s',
    'Pret A Manger',
    'Starbucks',
    'Caffè Nero',
    'Costa Coffee',
    'Greggs',
    'Leon',
    'Wagamama',
    'YO! Sushi',
    'PizzaExpress',
    'Franco Manca',
    'Gourmet Burger Kitchen',
    'Bella Italia',
    'Côte Brasserie',
    'Wahaca',
    'Bill\'s',
    'The Ivy',
    'Dishoom',
    'Hawksmoor',
    'Zizzi',
    'Byron',
    'Hard Rock Cafe',
    'Honest Burgers',
    'Nobu',
    'Gordon Ramsay Restaurants',
    'Hakkasan',
    'Duck & Waffle',
    'The Fat Duck',
    'Dinner by Heston Blumenthal',
    'Alain Ducasse at The Dorchester',
    'Le Gavroche',
    'Gymkhana',
    'Le Manoir aux Quat\'Saisons',
    'Sketch',
    'The Ritz Restaurant',
    'Restaurant Gordon Ramsay',
    'Marcus Wareing Restaurants',
    'Hélène Darroze at The Connaught',
    'The Ledbury',
    'Core by Clare Smyth',
    'Texture',
    'Fera at Claridge\'s',
    'Galvin at Windows',
    'The Wolseley',
    'The River Cafe',
    'St John Restaurant',
    'Quo Vadis',
    'Trullo',
    'Hoppers',
    'Bocca di Lupo',
    'Kiln',
    'Kricket',
    'The Palomar',
    'Brat',
    'Padella',
    'Barrafina',
    'Lyle\'s',
    'Brawn',
    'The Clove Club',
    'Nopi',
    'Rochelle Canteen',
    'Luca',
    'Quality Chop House',
    'Dishoom Carnaby',
    'Frenchie',
    'Sabor',
    'Sager + Wilde',
    'Berenjak',
    'Morito',
    'Black Axe Mangal',
    'Circolo Popolare',
    'Polpo',
    'Maison Bab',
    'Bar Douro',
    'The Barbary',
    'Kym\'s',
    'Kricket Brixton',
    'The Marksman',
    'Smoking Goat',
    'Ottolenghi',
    'Lina Stores',
    'Rovi',
    'Paradise',
    'Padella Shoreditch',
    'Evelyn\'s Table',
    'Scully St James\'s',
    'Lucky & Joy',
    'Arabica',
    'Zelman Meats',
    'Sambal Shiok'
]

entertainment_companies = [
    'Steam',
    'Epic Games',
    'Origin',
    'Ubisoft',
    'Rockstar Games',
    'Activision',
    'Blizzard Entertainment',
    'Electronic Arts',
    'Bethesda Softworks',
    'Square Enix',
    'Sony Interactive Entertainment',
    'Microsoft Game Studios',
    'Nintendo',
    'Warner Bros. Interactive Entertainment',
    'Netflix',
    'Amazon Prime Video',
    'Hulu',
    'HBO',
    'Disney+',
    'BBC iPlayer',
    'Now TV',
    'Crunchyroll',
    'Funimation',
    'Twitch',
    'YouTube',
    'Spotify',
    'Apple Music',
    'Tidal',
    'Deezer',
    'Pandora',
    'iHeartRadio',
    'Sirius XM',
    'Live Nation',
    'StubHub',
    'Ticketmaster',
    'AMC Theatres',
    'Cineworld',
    'Regal Cinemas',
    'Odeon',
    'Vue Cinemas',
    'Showcase Cinemas',
    'IMAX',
    'Cirque du Soleil',
    'Blue Man Group',
    'Disney Parks, Experiences and Products',
    'Universal Parks & Resorts',
    'SeaWorld Parks & Entertainment',
    'Six Flags Entertainment Corporation',
    'Merlin Entertainments',
    'Madame Tussauds',
    'Ripley\'s Believe It or Not!',
    'Legoland',
    'Dave & Buster\'s',
    'Chuck E. Cheese',
    'Topgolf',
    'Bowling Alley',
    'Escape Room',
    'Sky Zone',
    'iFly',
    'Gameworks',
    'Round One Entertainment',
    'Main Event Entertainment',
    'GameWorks',
    'Alamo Drafthouse Cinema',
    'Cinépolis',
    'Arclight Cinemas',
    'Landmark Theatres',
    'Angelika Film Center',
    'Laemmle Theatres',
    'Krikorian Theatres',
    'Goodrich Quality Theaters',
    'Marcus Theatres',
    'National Amusements',
    'Vue International',
    'Cineplex',
    'Cine Colombia',
    'Pathé',
    'Gaumont',
    'Kinepolis Group',
    'Toho',
    'Shochiku',
    'Shaw Organisation',
    'Golden Village',
    'CJ CGV',
    'Megabox',
    'PVR Cinemas',
    'Inox Leisure',
    'Mexicanal',
    'NuvoTV',
    'Univision Communications',
    'Telemundo',
    'SBS Broadcasting Group',
    'AMC Networks',
    'A&E Networks',
    'ViacomCBS',
    'Discovery, Inc.',
    'The Walt Disney Company',
    '21st Century Fox',
    'Comcast',
    'Sony Pictures Entertainment'


]

uk_gas_stations = [
    "BP",
    "Shell",
    "Esso",
    "Texaco",
    "Morrisons",
    "Asda",
    "Sainsbury's",
    "Tesco",
    "Gulf",
    "Jet",
    "Murco",
    "Total",
    "ExxonMobil",
    "Q8",
    "Co-op",
    "Applegreen",
    "Londis",
    "Spar",
    "Premier",
    "One Stop",
    "Maxol",
    "Mace",
    "Budgens",
    "Day-Today",
    "Morrisons Daily",
    "Shell Select",
    "BP M&S",
    "BP Express",
    "Sainsbury's Local",
    "Tesco Express",
    "Tesco Metro",
    "Esso Express",
    "Esso Shop",
    "Texaco Express",
    "Total Access",
    "Gulf Express",
    "Jet Express",
    "Co-op Food",
    "Costcutter",
    "Nisa Local",
    "Premier Express",
    "Londis Express",
    "Spar Express",
    "Bargain Booze",
    "Best-One",
    "Central Convenience",
    "Family Shopper",
    "Lifestyle Express",
    "Mace Express",
    "Martin's",
    "McColl's",
    "Premier Stores",
    "Simply Fresh",
    "Vivo",
    "Budgens Local",
    "Day-Today Express",
    "Morrisons Daily Local",
    "Nisa Extra",
    "Sainsbury's Local Extra",
    "Tesco Express Extra",
    "Texaco Service Station",
    "BP Connect",
    "Esso On The Run",
    "Spar Shop",
    "M&S Simply Food",
    "Shell Garage",
    "Gulf Service Station",
    "Jet Service Station",
    "Morrisons Daily Plus",
    "Premier Express Plus",
    "Sainsbury's Local Plus",
    "Texaco Service Station Plus",
    "Tesco Express Plus",
    "Esso On The Run Plus",
    "Co-op Food Plus",
    "Budgens Plus",
    "Nisa Plus",
    "Spar Plus",
    "Londis Plus",
    "Mace Plus",
    "Central Convenience Plus",
    "Premier Stores Plus",
    "Vivo Plus",
    "Best-One Plus",
    "Costcutter Plus",
    "Family Shopper Plus",
    "Lifestyle Express Plus",
    "Martin's Plus",
    "McColl's Plus",
    "Simply Fresh Plus",
    "Bargain Booze Plus",
    "Budgens Local Plus",
    "Day-Today Express Plus",
    "Morrisons Daily Local Plus",
    "Nisa Extra Plus",
    "Sainsbury's Local Extra Plus",
    "Tesco Express Extra Plus",
    "Texaco Service Station Extra",
    "BP Connect Plus",
    "Esso On The Run Extra"]

gift_companies = [
    'Amazon',
    'Etsy',
    'eBay',
    'Walmart',
    'Target',
    'Costco',
    'Best Buy',
    'Macy\'s',
    'Nordstrom',
    'Bloomingdale\'s',
    'Sephora',
    'Ulta Beauty',
    'Lush',
    'The Body Shop',
    'Bath & Body Works',
    'Yankee Candle',
    'Pandora',
    'Tiffany & Co.',
    'Swarovski',
    'Saks Fifth Avenue',
    'Neiman Marcus',
    'Anthropologie',
    'Uncommon Goods',
    'Wayfair',
    'Bed Bath & Beyond',
    'Pier 1 Imports',
    'West Elm',
    'Crate & Barrel',
    'Pottery Barn',
    'Williams-Sonoma',
    'Sur La Table',
    'Lululemon',
    'Nike',
    'Adidas',
    'Under Armour',
    'Victoria\'s Secret',
    'American Eagle Outfitters',
    'Gap',
    'H&M',
    'Zara',
    'Forever 21',
    'ASOS',
    'Urban Outfitters',
    'Free People',
    'ModCloth',
    'Topshop',
    'Missguided',
    'Boohoo',
    'Revolve',
    'Nasty Gal',
    'Fashion Nova',
    'Zazzle',
    'CafePress',
    'Personalization Mall',
    'Shutterfly',
    'Snapfish',
    'Minted',
    'Vistaprint',
    'Framebridge',
    'Artifact Uprising',
    'Blurb',
    'CanvasPop',
    'Mpix',
    'Winkflash',
    'PrestoPhoto',
    'CanvasWorld',
    'ProFlowers',
    '1-800-Flowers',
    'FTD',
    'Teleflora',
    'Edible Arrangements',
    'Harry & David',
    'Godiva',
    'See\'s Candies',
    'Sugarfina',
    'Dylan\'s Candy Bar',
    'Rocky Mountain Chocolate Factory',
    'Ghirardelli Chocolate Company',
    'Russell Stover',
    'Lindt & Sprüngli',
    'The Popcorn Factory',
    'Winc',
    'Vinebox',
    'Cellars Wine Club',
    'Gold Medal Wine Club',
    'Club W',
    'HelloFresh',
    'Blue Apron',
    'Freshly',
    'Home Chef',
    'Plated',
    'Green Chef',
    'Sun Basket',
    'Purple Carrot',
    'The Honest Company',
    'BabyGap',
    'Carter\'s',
    'The Children\'s Place',
    'Buy Buy Baby',
    'Pottery Barn Kids'
  
]


grocery_companies = [
    "Walmart",
    "Kroger",
    "Albertsons",
    "Aldi",
    "Lidl",
    "Safeway",
    "Publix",
    "Target",
    "Costco",
    "Whole Foods Market",
    "Trader Joe's",
    "Meijer",
    "Stop & Shop",
    "Giant Food",
    "H-E-B",
    "WinCo Foods",
    "Hy-Vee",
    "Food Lion",
    "Giant Eagle",
    "Wegmans",
    "Sprouts Farmers Market",
    "SuperValu",
    "Raley's",
    "Fred Meyer",
    "The Fresh Market",
    "Weis Markets",
    "Ingles Markets",
    "King Soopers",
    "Fry's Food Stores",
    "Smith's Food and Drug",
    "Mariano's",
    "Cub Foods",
    "Price Chopper",
    "Piggly Wiggly",
    "Schnucks",
    "Save Mart",
    "Roche Bros.",
    "Dierbergs",
    "Gelson's Markets",
    "Mollie Stone's Markets",
    "Bristol Farms",
    "New Seasons Market",
    "Wawa",
    "Sheetz",
    "QuikTrip",
    "RaceTrac",
    "Circle K",
    "7-Eleven",
    "Thorntons",
    "Casey's General Stores",
    "Family Express",
    "Kwik Trip",
    "Nice N Easy",
    "Stewart's Shops",
    "Cumberland Farms",
    "Speedway",
    "QuickChek",
    "Rutter's",
    "WaWa Food Market",
    "Turkey Hill Minit Markets",
    "Pilot Flying J",
    "Love's Travel Stops & Country Stores",
    "TravelCenters of America",
    "Sheetz Inc.",
    "QuikTrip Corporation",
    "Casey's Retail Company",
    "Kum & Go LC",
    "Maverik",
    "GPM Investments LLC",
    "Murphy USA",
    "United Refining Co.",
    "Enmark Stations Inc.",
    "Kwik Shop",
    "Buc-ee's",
    "Town Pump Inc.",
    "Minit Mart",
    "Huck's Food and Fuel",
    "Gate Petroleum Company",
    "Road Ranger",
    "Cenex",
    "Petro Stopping Centers",
    "TA Operating LLC",
    "Royal Farms",
    "Allsup's Convenience Stores",
    "MFA Oil",
    "EG Group",
    "Meijer Gas Station",
    "Hy-Vee Gas",
    "Giant Gas",
    "Sheetz Gas",
    "Rutter's Farm Stores",
    "Nice N Easy Gas",
    "Wawa Gas Station",
    "Thorntons Gas",
    "Cumberland Farms Gas",
    "Speedway Gas",
    "Kwik Fill",
    "Pilot Travel Centers",
    "Love's Travel Stops",
    "QuikTrip Gas Station"
]

holiday_companies = [
    "Expedia",
    "Booking.com",
    "TripAdvisor",
    "Kayak",
    "Priceline",
    "Travelocity",
    "Orbitz",
    "Hotels.com",
    "Agoda",
    "Airbnb",
    "VRBO",
    "HomeAway",
    "Couchsurfing",
    "Hostelworld",
    "Hotwire",
    "Hopper",
    "CheapOair",
    "Skyscanner",
    "Momondo",
    "Google Flights",
    "Opodo",
    "lastminute.com",
    "eDreams",
    "Travelzoo",
    "Secret Escapes",
    "Luxury Escapes",
    "Airfarewatchdog",
    "SeatGuru",
    "Hipmunk",
    "FareCompare",
    "OneTravel",
    "Expedia Group",
    "Travel Republic",
    "STA Travel",
    "Cruise Critic",
    "CruiseDirect",
    "Cruise Nation",
    "CruisesOnly",
    "Royal Caribbean International",
    "Norwegian Cruise Line",
    "Carnival Cruise Line",
    "Princess Cruises",
    "Celebrity Cruises",
    "Holland America Line",
    "Disney Cruise Line",
    "Oceania Cruises",
    "Regent Seven Seas Cruises",
    "Crystal Cruises",
    "Silversea Cruises",
    "Azamara Club Cruises",
    "MSC Cruises",
    "Viking Ocean Cruises",
    "AmaWaterways",
    "Uniworld Boutique River Cruise Collection",
    "Viking River Cruises",
    "CroisiEurope",
    "Riviera Travel",
    "APT",
    "Avalon Waterways",
    "American Cruise Lines",
    "Windstar Cruises",
    "Emerald Waterways",
    "Grand Circle Cruise Line",
    "CroisiVoyages",
    "Cruiseco",
    "Costa Cruises",
    "Pullmantur Cruises",
    "Fred. Olsen Cruise Lines",
    "Saga Cruises",
    "Marella Cruises",
    "Transat",
    "TUI Cruises",
    "Azamara",
    "Cunard",
    "Seabourn",
    "SeaDream Yacht Club",
    "Star Clippers",
    "Dream Yacht Charter",
    "The Moorings",
    "Sunsail",
    "Bareboat.com",
    "Le Boat",
    "GoBoat",
    "Airbnb Experiences",
    "Viator",
    "GetYourGuide",
    "City Sightseeing",
    "Big Bus Tours",
    "Busabout",
    "Intrepid Travel",
    "G Adventures",
    "Contiki",
    "Topdeck Travel",
    "Busbud",
    "Greyhound",
    "Amtrak",
    "Eurail",
    "Rail Europe",
    "Eurostar",
    "Renfe"

]

payment_companies_uk = [
    "Adyen",
    "Amazon Pay",
    "American Express",
    "Apple Pay",
    "Barclaycard",
    "Braintree",
    "ClearBank",
    "Currencycloud",
    "Elavon",
    "Faster Payments",
    "First Data",
    "Gocardless",
    "HSBC",
    "iZettle",
    "JCB",
    "Klarna",
    "Lloyds Bank",
    "Mastercard",
    "Monese",
    "Moneycorp",
    "Moneygram",
    "Monzo",
    "NatWest",
    "Neteller",
    "Nochex",
    "Paym",
    "PayPal",
    "Paysafe",
    "PayU",
    "Revolut",
    "Sage Pay",
    "Santander",
    "Skrill",
    "Square",
    "Starling Bank",
    "Stripe",
    "SumUp",
    "TransferWise",
    "Trustly",
    "Visa",
    "Western Union",
    "WorldFirst",
    "WorldPay",
    "AIB Merchant Services",
    "Allpay",
    "Alpha Payments Cloud",
    "Apco",
    "Auka",
    "BACS",
    "Bango",
    "Checkout.com",
    "Citizens Bank",
    "Clydesdale Bank",
    "Co-operative Bank",
    "Diners Club International",
    "Discover",
    "EcoPayz",
    "EmerchantPay",
    "Epay Global",
    "FEXCO",
    "Fidel",
    "Fintrax",
    "Fire Financial Services",
    "Flexepin",
    "Flywire",
    "Garanti BBVA",
    "Giropay",
    "GoCardless Pro",
    "Hipay",
    "Ingenico",
    "Interac",
    "Jaja Finance",
    "KashFlow",
    "Mangopay",
    "Moneymailme",
    "Moolahsense",
    "Moneysupermarket.com",
    "myPOS",
    "Nuapay",
    "Onfido",
    "Openpay",
    "Optimal Payments",
    "Pay360",
    "Payeer",
    "PaymentSense",
    "Payoneer",
    "Paypoint",
    "Payr",
    "Payzone",
    "Pendo",
    "Pockit",
    "PPRO",
    "Punchout2Go",
    "Red Dot Payment",
    "SafeCharge",
    "Secure Trading",
    "SmartDebit",
    "Sofort",
    "Talan",
    "Tandem Bank"

]

non_food_shops = [
    "Amazon",
    "Walmart",
    "Target",
    "Macy's",
    "Kohl's",
    "JCPenney",
    "Nordstrom",
    "Gap",
    "H&M",
    "Zara",
    "Forever 21",
    "Topshop",
    "Abercrombie & Fitch",
    "American Eagle Outfitters",
    "Adidas",
    "Nike",
    "Under Armour",
    "Lululemon",
    "Victoria's Secret",
    "Bath & Body Works",
    "Sephora",
    "Ulta Beauty",
    "MAC Cosmetics",
    "The Body Shop",
    "Lush",
    "Hobby Lobby",
    "Michaels",
    "Jo-Ann Fabric and Craft Stores",
    "Staples",
    "Office Depot",
    "Best Buy",
    "GameStop",
    "EB Games",
    "Microsoft Store",
    "Apple Store",
    "Verizon Wireless",
    "AT&T",
    "T-Mobile",
    "Sprint",
    "Vodafone",
    "O2",
    "EE",
    "Three",
    "Virgin Media",
    "Sky",
    "BT",
    "Currys PC World",
    "Dixons Travel",
    "John Lewis",
    "IKEA",
    "Home Depot",
    "Lowe's",
    "Ace Hardware",
    "Menards",
    "B&Q",
    "Wickes",
    "Screwfix",
    "The Range",
    "Argos",
    "B&M",
    "Poundland",
    "Dollar Tree",
    "Dollar General",
    "Big Lots",
    "The Container Store",
    "Bed Bath & Beyond",
    "Williams Sonoma",
    "Crate & Barrel",
    "Pottery Barn",
    "West Elm",
    "Anthropologie",
    "Free People",
    "Urban Outfitters",
    "Banana Republic",
    "J.Crew",
    "Madewell",
    "The North Face",
    "Patagonia",
    "REI",
    "Dick's Sporting Goods",
    "Gander Outdoors",
    "Cabela's",
    "Bass Pro Shops",
    "PetSmart",
    "Petco",
    "Guitar Center",
    "Sam Ash Music",
    "Fender",
    "Gibson",
    "Martin Guitar",
    "Casio",
    "Yamaha",
    "Steinway & Sons",
    "Sweetwater",
    "GNC",
    "The Vitamin Shoppe",
    "Holland & Barrett",
    "Boots",
    "Walgreens",
    "CVS"

]

bus_companies = [
    "National Express",
    "Stagecoach",
    "First Bus",
    "Arriva",
    "Go-Ahead Group",
    "Bluestar",
    "Brighton & Hove",
    "Buses Excetera",
    "Caledonian MacBrayne",
    "Cardiff Bus",
    "Centrebus",
    "Chambers",
    "Chiltern Railways",
    "City Sightseeing",
    "Citybus",
    "Coastliner",
    "Compass Travel",
    "CT Plus",
    "Diamond Bus",
    "East Yorkshire Motor Services",
    "Eastons",
    "Edwards Coaches",
    "Ensignbus",
    "EYMS",
    "Faresaver",
    "Fearnley's",
    "First Aberdeen",
    "First Berkshire",
    "First Cymru",
    "First Glasgow",
    "First Hampshire & Dorset",
    "First Kernow",
    "First Manchester",
    "First Midlands",
    "First Norfolk & Suffolk",
    "First Potteries",
    "First South Yorkshire",
    "First West of England",
    "First York",
    "Flixbus",
    "Fylde Bus & Coach",
    "Galloway European",
    "Gareth Joyner",
    "Golden Tours",
    "Gray Line",
    "Green Line",
    "Grosvenor Coach",
    "Hams Travel",
    "Hedingham",
    "Heritage Bus",
    "High Peak",
    "Hulleys of Baslow",
    "Ipswich Buses",
    "Island Buses",
    "Jackies Coaches",
    "Johnson's Coach & Bus Travel",
    "Keane Travel",
    "Kennections",
    "Konectbus",
    "Lancashire United",
    "Laws Coaches",
    "Leger Holidays",
    "Lothian Buses",
    "M&H Coaches",
    "Mainline Bus",
    "Majestic Travel",
    "Mayne Coaches",
    "McGill's Bus Services",
    "Megabus",
    "Metrobus",
    "Metroline",
    "Millbrook",
    "Mitcham Belle",
    "Morebus",
    "National Holidays",
    "NAT Group",
    "New Adventure Travel",
    "Newport Bus",
    "Nimbus Coaches",
    "Nobles Tours",
    "North Norfolk Bus",
    "Northumberland Bus Company",
    "Nottingham City Transport",
    "Nu-Venture",
    "Oakwood Travel",
    "Oxford Bus Company",
    "Parks of Hamilton",
    "Pats Coaches",
    "Perryman's Buses",
    "Plymouth Citybus",
    "Preston Bus",
    "Pullman Bus",
    "Reading Buses",
    "Red Eagle",
    "Redwing Coaches",
    "Regal Busways",
    "Richmond's Coaches",
    "Rotala",
    "Routemaster Buses",
    "Safeguard Coaches"

]

train_companies = [
    "Amtrak",
    "Eurostar",
    "SNCF",
    "Renfe",
    "Deutsche Bahn",
    "Virgin Trains",
    "Thalys",
    "TGV",
    "Frecciarossa",
    "Italo",
    "SJ",
    "NSB",
    "SBB",
    "VR",
    "TransPennine Express",
    "East Midlands Trains",
    "Northern Rail",
    "London Northwestern Railway",
    "West Midlands Trains",
    "Greater Anglia",
    "South Western Railway",
    "Gatwick Express",
    "Heathrow Express",
    "Thameslink",
    "Southern Rail",
    "Great Western Railway",
    "South Eastern Railway",
    "C2C",
    "Translink",
    "ScotRail",
    "Eurostar Italia",
    "Trenitalia",
    "Trenord",
    "NTV",
    "Euskotren",
    "Trenes Argentinos",
    "VIA Rail",
    "Ontario Northland",
    "Rocky Mountaineer",
    "Alaska Railroad",
    "Caltrain",
    "VRE",
    "MARC Train",
    "Metrolink",
    "Sound Transit",
    "SEPTA",
    "PATH",
    "MTA",
    "MBTA",
    "New Jersey Transit",
    "Amtrak Cascades",
    "SunRail",
    "Tri-Rail",
    "Brightline",
    "Metra",
    "South Shore Line",
    "Capitol Corridor",
    "Altamont Corridor Express",
    "BART",
    "Caltrans",
    "SMART",
    "ACE",
    "NCTD",
    "Coaster",
    "Metrolinx",
    "UP Express",
    "GO Transit",
    "VIA Rail Canada",
    "Keolis",
    "Abellio",
    "Transdev",
    "Arriva UK Trains",
    "MTR Corporation",
    "Hong Kong Tramways",
    "MTR Express",
    "FlixTrain",
    "Trenes Metropolitanos",
    "Alstom",
    "Siemens",
    "CAF",
    "Hitachi Rail",
    "Bombardier Transportation",
    "Stadler Rail",
    "CRRC",
    "Škoda Transportation",
    "Hyundai Rotem",
    "Kawasaki Heavy Industries",
    "Nippon Sharyo",
    "JR East",
    "JR West",
    "JR Central",
    "Tokyo Metro",
    "Keikyu",
    "Keio",
    "Keisei",
    "Odakyu",
    "Seibu",
    "Tobu",
    "Tokyu",
    "Hanshin"

]


    #mortgage_companies 
    #mortgage_companies 
    #uk_councils
    #uk_water_companies
    #uk_energy_providers
    #uk_councils,100
    #uk_charities
    #restaurants
    #entertainment_companies
    #train_companies
    #restaurants
    #uk_gas_stations
    #gift_companies,20
    #grocery_companies
    #holiday_companies
    #payment_companies_uk
    #non_food_shops
    #train_companies
    #bus_companies
    #uk_gas_stations


import numpy as np
import random
import math

#Morgage
#Rent
#Water_Bill
#ElectrictyGasBill
#income

charity_alternatives = ["Volunteer Instead","Give Less Money","Check Charity Rating","Donate Clothes Instead","Donate Items",
                        "Sell Items To give","Raise Awareness Instead","Do A Fund Raiser","Do A sponsored Walk"]

Eatingout_alternatives = ["Make Food At Home","Bring Food With you","Choose Cheaper Restaurant","Don't Order Expensive Drinks","Check For Coupons",
                        "Go To A Buffet","Split The Bill","Skip Starters","Skip Desert"]

Entertainment_Alternatives = ["Buy A Subscription","Play A Board Game","Stay At Home","Find A Coupon","Book Last Minute",
                        "Book Cheaper Seats","Get A Group Discount","Don't Get Drinks","Get An Uber Back"]

Holiday_Alternatives = ["Don't Go Abroad","Look For Discounts","Rebook If Price Changes","Ask For Deal","Choose Cheaper Country",
                        "Don't Get Drinks Package","Book On Cheaper Airline"]

Gift_alt = ["Make The Gift Yourself","Choose Cheaper Gift","Get A Card Instead","Re-Gift Something","Plant A Tree For Them",
                        "Adopt A Donkey For Them"]

Shopping_alt = ["Don't Buy New Clothes","Stay At Home","Get Loyalty Card","Only Buy Discounted","Go On Clearance Sale"]


for person in range (1,1001):

    intervals = [random.randint(1, 30),random.randint(1, 30),random.randint(1, 30),random.randint(1, 30),random.randint(1, 30)]

    CompanyName = [mortgage_companies[random.randint(0, len(mortgage_companies)-1)],mortgage_companies[random.randint(0, len(mortgage_companies)-1)],
    uk_water_companies[random.randint(0, len(uk_water_companies)-1)],uk_energy_providers[random.randint(0, len(uk_energy_providers)-1)],
    payment_companies_uk[random.randint(0, len(payment_companies_uk)-1)]]

    means = [759,1143,34,115,2650]
    #round(750 / 4)

    costs = [str(-round(random.normalvariate(means[0],  round(means[0]/4)))),
    str(-round(random.normalvariate(means[1], round(means[1]/4)))),
    str(-round(random.normalvariate(means[2], round(means[2]/4)))),
    str(-round(random.normalvariate(means[3], round(means[3]/4)))),
    str(round(random.normalvariate(means[4], round(means[4]/4))))]


    Category = ["Bills","Bills","Bills","Bills","Income"]

    SubCategory = ["Mortgage","Rent","Water","Energy","Income"]

    indexs = ["InterestRate", "Inflation", "Water", "Energy", ""]

    wantorneedd = ["need", "need", "need", "need", ""]

    file = open("files.txt","a", encoding="utf8")

    ifskip = random.randint(0, 1)

    for j in range(0, 5):

        if (ifskip == j):
            continue

        for i in range(1, 366):
            if i % 30 == intervals[j]:
                costs[2] = str(-round(random.normalvariate(means[2],  round(means[2]/4))))
                costs[3] = str(-round(random.normalvariate(means[3],  round(means[3]/4))))
            
                file.write(str(person) + "|")
                file.write(str(i) + "|")
                file.write(str(random.randint(0, 23)) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
                file.write(Category[j] + "|")
                file.write(SubCategory[j] + "|")
                file.write(CompanyName[j] + "|")
                file.write(costs[j] + "|")
                file.write(wantorneedd[j] + "|")
                file.write(indexs[j] + "|")
                file.write("" + "|")
                file.write("\n")

#############################################################################################################
#council tax

    file.write(str(person) + "|")
    file.write(str(random.randint(1, 365)) + "|")
    file.write(str(random.randint(0, 23)) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
    file.write("Bills" + "|")
    file.write("CouncilTax" + "|")
    file.write(uk_councils[random.randint(0, len(uk_councils)-1)] + "|")
    file.write(str(-1*(round(random.normalvariate(159,  round(159/4))))) + "|")
    file.write("need" + "|")
    file.write("Inflation" + "|")
    file.write("" + "|")
    file.write("\n")

##############################################################################################################
#charity

    for i in range(1, 366):

        baseprob = 4
        if ((i % 7) < 6) and ((i % 7) != 0):
            baseprob = baseprob * 8

        hour = round(random.normalvariate(19,  1))
        if (hour > 23) or (hour < 0):
            hour = 19

        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Charity" + "|")
            file.write("Charity" + "|")
            file.write(uk_charities[random.randint(0, len(uk_charities)-1)] + "|")
            file.write(str(-round(random.normalvariate(49,  round(49/4)))) + "|")
            file.write("want" + "|")
            file.write("" + "|")
            file.write(charity_alternatives[random.randint(0,len(charity_alternatives)-1)] + "|")
            file.write("\n")
        

##############################################################################################################
#eating out

    for i in range(1, 366):

        baseprob = 15
        if ((i % 7) > 5) and ((i % 7) == 0):
            baseprob = baseprob * 10

        hour = round(random.normalvariate(14,  2))
        if (hour > 23) or (hour < 0):
            hour = 14

        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Eating Out" + "|")
            file.write("Eating Out" + "|")
            file.write(restaurants[random.randint(0, len(restaurants)-1)] + "|")
            file.write(str(-round(random.normalvariate(53,  round(53/4)))) + "|")
            file.write("want" + "|")
            file.write("Inflation" + "|")
            file.write(Eatingout_alternatives[random.randint(0,len(Eatingout_alternatives)-1)] + "|")
            file.write("\n")

##############################################################################################################
#entertainement

    for i in range(1, 366):

        baseprob = 52


        hour = round(random.normalvariate(22,  2))
        if (hour > 23) or (hour < 0):
            hour = 14

        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Entertainment" + "|")
            file.write("Entertainment" + "|")
            file.write(entertainment_companies[random.randint(0, len(entertainment_companies)-1)] + "|")
            file.write(str(-round(random.normalvariate(89,  round(89/4)))) + "|")
            file.write("want" + "|")
            file.write("Inflation" + "|")
            file.write(Entertainment_Alternatives[random.randint(0,len(Entertainment_Alternatives)-1)] + "|")
            file.write("\n")

##############################################################################################################
#expenses

    for j in range (0,4):

        for i in range(1, 366):

            DaCompanyName = [bus_companies[random.randint(0, len(bus_companies)-1)],train_companies[random.randint(0, len(train_companies)-1)],
            restaurants[random.randint(0, len(restaurants)-1)],uk_gas_stations[random.randint(0, len(uk_gas_stations)-1)]]

            expenesessubat = ["Bus","Train","Food","Fuel"]

            daindex = ["Inflation","Inflation","Inflation","Fuel"]

            expenesessubatprice = [10,20,5,50]

            baseprob = 20

            if ((i % 7) < 6) and ((i % 7) != 0):
                baseprob = baseprob * 4

            hour = round(random.normalvariate(9,  2))
            if (hour > 23) or (hour < 0):
                hour = 9

            roll = random.randint(1, 365)
            if (roll <= baseprob):
                file.write(str(person) + "|")
                file.write(str(i) + "|")
                file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
                file.write("Expenses" + "|")
                file.write(expenesessubat[j] + "|")
                file.write(DaCompanyName[j] + "|")
                file.write(str(-round(random.normalvariate(expenesessubatprice[j],  round(expenesessubatprice[j]/4)))) + "|")
                file.write("need" + "|")
                file.write(daindex[j] + "|")
                file.write("" + "|")
                file.write("\n")

##############################################################################################################  
#gifts

    for i in range(1, 366):

        baseprob = 32


        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(random.randint(0, 23)) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Gifts" + "|")
            file.write("Gifts" + "|")
            file.write(gift_companies[random.randint(0, len(gift_companies)-1)] + "|")
            file.write(str(-round(random.normalvariate(13,  round(13/4)))) + "|")
            file.write("want" + "|")
            file.write("Inflation" + "|")
            file.write(Gift_alt[random.randint(0,len(Gift_alt)-1)] + "|")
            file.write("\n")


############################################################################################################## 
#groceries

    for i in range(1, 366):

        baseprob = 32

        hour = round(random.normalvariate(20,  2))
        if (hour > 23) or (hour < 0):
            hour = 20


        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Groceries" + "|")
            file.write("Groceries" + "|")
            file.write(grocery_companies[random.randint(0, len(grocery_companies)-1)] + "|")
            file.write(str(-round(random.normalvariate(70,  round(70/4)))) + "|")
            file.write("need" + "|")
            file.write("Inflation" + "|")
            file.write("" + "|")
            file.write("\n")

##############################################################################################################
#holidays

    for i in range(1, 366):

        baseprob = 1


        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(random.randint(0, 23)) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Holidays" + "|")
            file.write("Holidays" + "|")
            file.write(holiday_companies[random.randint(0, len(holiday_companies)-1)] + "|")
            file.write(str(-round(random.normalvariate(730,  round(730/4)))) + "|")
            file.write("want" + "|")
            file.write("Inflation" + "|")
            file.write(Holiday_Alternatives[random.randint(0,len(Holiday_Alternatives)-1)] + "|")
            file.write("\n")

##############################################################################################################
#Shopping (no food)

    for i in range(1, 366):

        hour = round(random.normalvariate(12,  2))
        if (hour > 23) or (hour < 0):
            hour = 12

        baseprob = 15
        if ((i % 7) > 5) and ((i % 7) == 0):
            baseprob = baseprob * 10

        roll = random.randint(1, 365)
        if (roll <= baseprob):
            file.write(str(person) + "|")
            file.write(str(i) + "|")
            file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
            file.write("Shopping" + "|")
            file.write("Shopping" + "|")
            file.write(non_food_shops[random.randint(0, len(non_food_shops)-1)] + "|")
            file.write(str(-round(random.normalvariate(100,  round(100/4)))) + "|")
            file.write("want" + "|")
            file.write("Inflation" + "|")
            file.write(Shopping_alt[random.randint(0,len(Shopping_alt)-1)] + "|")
            file.write("\n")

##############################################################################################################
#transport

    for j in range (0,3):

        for i in range(1, 366):

            DaCompanyName = [bus_companies[random.randint(0, len(bus_companies)-1)],train_companies[random.randint(0, len(train_companies)-1)],
                         uk_gas_stations[random.randint(0, len(uk_gas_stations)-1)]]

            expenesessubat = ["Bus","Train","Fuel"]

            daindex = ["Inflation","Inflation","Fuel"]

            expenesessubatprice = [10,20,50]

            baseprob = 15

            if ((i % 7) < 6) and ((i % 7) != 0):
                baseprob * 5

            hour = round(random.normalvariate(16,  2))
            if (hour > 23) or (hour < 0):
                hour = 16

            roll = random.randint(1, 365)
            if (roll <= baseprob):
                file.write(str(person) + "|")
                file.write(str(i) + "|")
                file.write(str(hour) + ":" + str(random.randint(0, 59))+ ":" + str(random.randint(0, 59)) + "|")
                file.write("Transport" + "|")
                file.write(expenesessubat[j] + "|")
                file.write(DaCompanyName[j] + "|")
                file.write(str(-round(random.normalvariate(expenesessubatprice[j],  round(expenesessubatprice[j]/4)))) + "|")
                file.write("need" + "|")
                file.write(daindex[j] + "|")
                file.write("" + "|")
                file.write("\n")

############################################################################################################## 
        
    file.close()



